#!/bin/bash
ntpq -p
