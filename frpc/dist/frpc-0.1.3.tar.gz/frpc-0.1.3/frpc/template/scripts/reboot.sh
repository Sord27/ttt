#!/bin/bash
/bam/scripts/rebootBAM
