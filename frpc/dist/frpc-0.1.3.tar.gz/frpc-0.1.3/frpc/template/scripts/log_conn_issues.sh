#!/bin/bash
. /bam/scripts/bamfunc.sh
bam_log_error 'bloh_soc_init Resource temporarily unavailable'
