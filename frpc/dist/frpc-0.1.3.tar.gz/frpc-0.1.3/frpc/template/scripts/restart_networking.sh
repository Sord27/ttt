#!/bin/bash
/etc/init.d/networking restart
