
"""frpc main package."""

NUMVERSION = (0, 1, 3)
VERSION = ".".join(str(num) for num in NUMVERSION)
