#!/bin/bash
cat /bam/etc/bam.mac
