#!/bin/bash
/bam/scripts/bamstat
