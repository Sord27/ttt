#!/bin/bash
stopBAM; startBAM
