#!/bin/bash
cat /bam/release /release
