#!/bin/bash
echo > /dev/null
