#!/bin/bash
/bam/scripts/bamnet start &>/dev/null &
